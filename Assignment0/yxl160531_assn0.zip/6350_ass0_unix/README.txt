The text file that I chosen is "The Project Gutenberg EBook of A Tale of Two Cities", by Charles Dickens.
To run the command file, unzip yxl160531_assn0.zip, go to folder 6350_ass0_unix and 
execute 
	sh  wordcount.sh 

